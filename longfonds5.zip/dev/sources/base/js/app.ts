/**
 * TypeScript
 */
